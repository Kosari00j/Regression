import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt

# بارگذاری داده‌ها از فایل اکسل
data_path = 'dataR/Real estate valuation data set.xlsx'  # مسیر فایل اکسل
data = pd.read_excel(data_path)

# نمایش 5 سطر اول دیتاست
print("First 5 rows of the dataset:")
print(data.head())

# توصیف آماری داده‌ها
print("\nStatistical summary of the data:")
print(data.describe())

# نمایش نوع داده‌ها
print("\nData types of each feature:")
print(data.dtypes)

# بررسی مقادیر گمشده
print("\nMissing values in the dataset:")
print(data.isnull().sum())

# ویژگی‌ها و هدف
X = data.drop('Y house price of unit area', axis=1)  # ویژگی‌ها (تمام ستون‌ها بجز هدف)
y = data['Y house price of unit area']  # قیمت خانه‌ها (هدف)

# تقسیم داده‌ها به مجموعه آموزش و آزمون (70% آموزش و 30% آزمون)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# مدل‌های رگرسیونی خطی
linear_reg = LinearRegression()
ridge_reg = Ridge(alpha=1.0)

# مدل‌های غیرخطی
dt_reg = DecisionTreeRegressor(random_state=42)
rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)

# آموزش مدل‌ها
linear_reg.fit(X_train, y_train)
ridge_reg.fit(X_train, y_train)
dt_reg.fit(X_train, y_train)
rf_reg.fit(X_train, y_train)

# پیش‌ بینی با مدل‌ها
y_pred_linear = linear_reg.predict(X_test)
y_pred_ridge = ridge_reg.predict(X_test)
y_pred_dt = dt_reg.predict(X_test)
y_pred_rf = rf_reg.predict(X_test)

# ارزیابی مدل‌ها
def rmse(y_true, y_pred):
    return np.sqrt(mean_squared_error(y_true, y_pred))

# ارزیابی مدل‌ها

# Linear Regression
mae_linear = mean_absolute_error(y_test, y_pred_linear)
rmse_linear = rmse(y_test, y_pred_linear)
r2_linear = r2_score(y_test, y_pred_linear)

# Ridge Regression
mae_ridge = mean_absolute_error(y_test, y_pred_ridge)
rmse_ridge = rmse(y_test, y_pred_ridge)
r2_ridge = r2_score(y_test, y_pred_ridge)

# Decision Tree Regressor
mae_dt = mean_absolute_error(y_test, y_pred_dt)
rmse_dt = rmse(y_test, y_pred_dt)
r2_dt = r2_score(y_test, y_pred_dt)

# Random Forest Regressor
mae_rf = mean_absolute_error(y_test, y_pred_rf)
rmse_rf = rmse(y_test, y_pred_rf)
r2_rf = r2_score(y_test, y_pred_rf)

# نمایش نتایج ارزیابی
print("Linear Regression Metrics:")
print(f"MAE: {mae_linear:.4f}, RMSE: {rmse_linear:.4f}, R²: {r2_linear:.4f}\n")

print("Ridge Regression Metrics:")
print(f"MAE: {mae_ridge:.4f}, RMSE: {rmse_ridge:.4f}, R²: {r2_ridge:.4f}\n")

print("Decision Tree Regressor Metrics:")
print(f"MAE: {mae_dt:.4f}, RMSE: {rmse_dt:.4f}, R²: {r2_dt:.4f}\n")

print("Random Forest Regressor Metrics:")
print(f"MAE: {mae_rf:.4f}, RMSE: {rmse_rf:.4f}, R²: {r2_rf:.4f}\n")

# مقایسه مدل‌ها به صورت گرافیکی
models = ['Linear Regression', 'Ridge Regression', 'Decision Tree', 'Random Forest']
mae_values = [mae_linear, mae_ridge, mae_dt, mae_rf]
rmse_values = [rmse_linear, rmse_ridge, rmse_dt, rmse_rf]
r2_values = [r2_linear, r2_ridge, r2_dt, r2_rf]

# رسم نمودار میله‌ای برای MAE
plt.figure(figsize=(10, 6))
plt.bar(models, mae_values, color=['blue', 'green', 'orange', 'red'])
plt.title('Mean Absolute Error (MAE) Comparison')
plt.ylabel('Mean Absolute Error')
plt.show()

# رسم نمودار میله‌ای برای RMSE
plt.figure(figsize=(10, 6))
plt.bar(models, rmse_values, color=['blue', 'green', 'orange', 'red'])
plt.title('Root Mean Squared Error (RMSE) Comparison')
plt.ylabel('Root Mean Squared Error')
plt.show()

# رسم نمودار میله‌ای برای R²
plt.figure(figsize=(10, 6))
plt.bar(models, r2_values, color=['blue', 'green', 'orange', 'red'])
plt.title('R² Score Comparison')
plt.ylabel('R² Score')
plt.show()

